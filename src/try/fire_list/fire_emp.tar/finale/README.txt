Instruction to compile & run

1. Run make
2. Execute ./fire_emp

